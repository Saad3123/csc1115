Hi AJ, I did all the error testing and it's all good.

I tried to implement every possible thing I can :)
	nav, div, id, classes, internal links, external links ,enternal links which open in new page, 
	insted of <rowspan> and <colspan> I created "row" and individual columns such as "col-1" adn "col-2" 
	and implemented table, JS, images, hovers, lists, flexbox etc.

Note: I didn't have any professinal pic of mine that can be added to my porfolio, that's why I used "img/me2.png" 
	as default.

LINK TO MY GITHUB: https://github.com/Saad3123/csc1115.git